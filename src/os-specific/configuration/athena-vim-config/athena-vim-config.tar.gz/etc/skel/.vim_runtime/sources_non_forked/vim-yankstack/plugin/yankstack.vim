call yankstack#setup()
