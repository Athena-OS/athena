runtime! syntax/javascript.vim
