runtime! syntax/typescript.vim
