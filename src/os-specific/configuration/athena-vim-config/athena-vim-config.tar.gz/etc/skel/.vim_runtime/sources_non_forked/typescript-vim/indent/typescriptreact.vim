runtime! indent/typescript.vim
