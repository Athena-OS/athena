runtime ftplugin/coffee.vim
