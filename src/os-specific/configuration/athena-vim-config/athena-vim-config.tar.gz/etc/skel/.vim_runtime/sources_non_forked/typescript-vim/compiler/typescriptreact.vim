runtime! compiler/typescript.vim
