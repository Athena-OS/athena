v1.7.0
======

Features
--------

- Require Python 3.8 or later.


1.6
---

Re-release with updated project metadata.

1.5
---

#2: Added support for whitelisting origins.

Tagged commits are automatically released to PyPI.

1.4
---

Move hosting to Github
