# This file is a work of a US government employee and as such is in the Public domain.
# Simson L. Garfinkel, March 12, 2012
./affconvert -o file://:password@/fatty.afd fatty.raw
