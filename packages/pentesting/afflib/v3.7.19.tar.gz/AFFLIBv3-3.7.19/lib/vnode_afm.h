/*
 * Distributed under the Berkeley 4-part license
 */

extern struct af_vnode vnode_afm;
#define AFM_DEFAULT_PAGESIZE 1024*1024*16
