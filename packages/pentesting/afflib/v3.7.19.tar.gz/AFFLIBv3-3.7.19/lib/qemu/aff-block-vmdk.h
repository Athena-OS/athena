/* Simson Garfinkel's fake header to make block-vmdk.c compile */
#include "affconfig.h"
#include "afflib.h"
#include "afflib_i.h"

