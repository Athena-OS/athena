/*
 * Distributed under the Berkeley 4-part license
 */

extern struct af_vnode vnode_aff;	/* vnode_aff.cpp */


